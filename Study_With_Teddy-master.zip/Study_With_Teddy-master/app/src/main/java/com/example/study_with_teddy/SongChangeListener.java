package com.example.study_with_teddy;

public interface SongChangeListener {

    void onChanged(int position);

    }

