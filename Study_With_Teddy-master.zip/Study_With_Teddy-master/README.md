# MAD-Mini-Project

Study with Teddy – Mobile Application – 2nd Year Group Project

This project was carried out using Java with Android studio with Firebase.


# Contributors
Group Leader - Mr. Chathum Dewanmina Adhihetty (Chathum10)

Member 2 - Ms. Pawani Muthusala Perera(MuthusalaPerera)

Member 3 - Ms. Gangamini Athmaja Suriyawatta (GangaminiAthmaja)

Member 4 - Ms.Piyumika Kavindi Almeda (PIYUMI99)
